package cn.thinkingdata.android;

import android.app.Application;
import android.content.Context;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.runner.AndroidJUnitRunner;

import cn.dataeye.android.DataEyeDataHandle;
import cn.dataeye.android.DataEyeDatabaseAdapter;
import cn.dataeye.android.DataEyeConfig;
import cn.dataeye.android.DataEyeAnalyticsSDK;
import cn.thinkingdata.android.demo.TDTracker;
import cn.dataeye.android.utils.DataEyeLog;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class TestRunner extends AndroidJUnitRunner {


    /**
     * 项目APP_ID，在申请项目时会给出
     */
    private static final String TA_APP_ID = "debug-appid";
    private static final String TA_APP_ID_DEBUG = "debug-appid";

    /**
     * 数据上传地址
     * 如果您使用的是云服务，请输入以下URL:
     * http://receiver.ta.thinkingdata.cn:9080
     * 如果您使用的是私有化部署的版本，请输入以下URL:
     * http://数据采集地址:9080
     */
    private static final String TA_SERVER_URL = "https://biapi.adsgreat.cn/logbu";

    private static final int POLL_WAIT_SECONDS = 2;
    private static final BlockingQueue<JSONObject> messages = new LinkedBlockingQueue<>();

    public static JSONObject getEvent() throws InterruptedException {
        return messages.poll(POLL_WAIT_SECONDS, TimeUnit.SECONDS);
    }

    private static DataEyeAnalyticsSDK mInstance;
    private static DataEyeAnalyticsSDK mDebugInstance;

    public static DataEyeAnalyticsSDK getInstance() {
        return  mInstance;
    }

    public static DataEyeAnalyticsSDK getDebugInstance() {
        return mDebugInstance;
    }

    /** 初始化 TA SDK */
    private void initThinkingDataSDK() {
        DataEyeAnalyticsSDK.enableTrackLog(true);
        Context mAppContext = ApplicationProvider.getApplicationContext();
        DataEyeConfig mConfig = DataEyeConfig.getInstance(mAppContext, TA_APP_ID, TA_SERVER_URL);
        final DataEyeDataHandle dataEyeDataHandle = new DataEyeDataHandle(mAppContext) {
            @Override
            protected DataEyeDatabaseAdapter getDbAdapter(Context context) {
                return new DataEyeDatabaseAdapter(context) {
                    @Override
                    public int addJSON(JSONObject j, Table table, String token) {
                        try {
                            DataEyeLog.i("THINKING_TEST", j.toString(4));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        messages.add(j);
                        return 1;
                    }
                };
            }
        };
        mInstance =new DataEyeAnalyticsSDK(mConfig) {
            @Override
            protected DataEyeDataHandle getDataHandleInstance(Context context) {
                return dataEyeDataHandle;
            }
        };

        DataEyeAnalyticsSDK.addInstance(mInstance, mAppContext, TA_APP_ID);
        mDebugInstance = new DataEyeAnalyticsSDK(DataEyeConfig.getInstance(mAppContext, TA_APP_ID_DEBUG, TA_SERVER_URL)) {
            @Override
            protected DataEyeDataHandle getDataHandleInstance(Context context) {
                return dataEyeDataHandle;
            }
        };
        DataEyeAnalyticsSDK.addInstance(mDebugInstance, mAppContext, TA_APP_ID_DEBUG);

        TDTracker.initThinkingDataSDK(mInstance, mDebugInstance);
    }

    @Override
    public void callApplicationOnCreate(Application app) {
        initThinkingDataSDK();
    }
}
